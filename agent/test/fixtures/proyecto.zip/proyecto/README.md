# Proyecto ñandú
Cálculo de promedios.
