def promedio(xs):
    if not xs:
        return 0
    return sum(xs)/len(xs)

print(promedio([1,2,3]))
